import React, { useState } from "react";

const Monthly = () => {
  const days = Array.from({ length: 31 }, (_, i) => i + 1);
  const tasks = [
    "Complete Project Report",
    "Monthly Review Meeting",
    "Financial Summary",
    "Team Building Activity",
    "Personal Development Session"
  ];

  // State to track each task's completion day for the month
  const [dayStatus, setDayStatus] = useState(tasks.map(() => Array(31).fill(false)));

  // Handle day completion for a specific task
  const handleDayClick = (taskIndex, dayIndex) => {
    setDayStatus((prevStatus) =>
      prevStatus.map((taskDays, index) =>
        index === taskIndex && !taskDays.includes(true) // Ensure only one day can be selected per task
          ? taskDays.map((day, i) => (i === dayIndex ? true : day))
          : taskDays
      )
    );
  };

  return (
    <div className="bg-white p-2 rounded-lg shadow-md max-w-l ">
      <h2 className="text-lg font-semibold mb-4 text-center text-gray-800">Monthly Goals</h2>
      <div className="overflow">
        <table className="min-w-full border border-gray-300 bg-white text-xs">
          <thead>
            <tr>
              <th className="px-1 py-2 border-r bg-gray-200 text-xs">Tasks</th>
              {days.map((day) => (
                <th key={day} className="px-1 py-2 border-r text-gray-700 bg-grazy-100">
                  {day}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {tasks.map((task, taskIndex) => (
              <tr key={taskIndex} className="text-center border-b">
                <td className="px-1 py-2 border-r text-gray-700 font-medium">{task}</td>
                {days.map((_, dayIndex) => (
                  <td key={dayIndex} className="px-1 py-2 border-r">
                    <input
                      type="checkbox"
                      checked={dayStatus[taskIndex][dayIndex]}
                      onChange={() => handleDayClick(taskIndex, dayIndex)}
                      disabled={dayStatus[taskIndex].some((status) => status)}
                      className="h-4 w-4 cursor-pointer"
                    />
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Monthly;
