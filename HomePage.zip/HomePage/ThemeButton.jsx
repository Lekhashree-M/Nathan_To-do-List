import React from "react";
import { useTheme } from "./ThemeContext"; // Import the custom hook

function ThemeButton() {
  // Extract the `darkMode` and `toggleTheme` values from the context
  const { darkMode, toggleTheme } = useTheme();

  return (
    <header className="p-4 flex justify-between items-center">
      <h1 className="text-2xl font-bold">My App</h1>
      <button
        onClick={toggleTheme}
        className="px-4 py-2 bg-blue-500 text-white rounded"
      >
        {darkMode ? "Light Mode" : "Dark Mode"}
      </button>
    </header>
  );
}

export default ThemeButton;
