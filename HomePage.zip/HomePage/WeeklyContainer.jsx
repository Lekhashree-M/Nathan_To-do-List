import React, { useState } from "react";

const WeeklyContainer = () => {
  const days = ["M", "T", "W", "T", "F", "S", "S"];
  const tasks = [
    "1. Reading",
    "2. Listening to Music",
    "3. Exercise",
    "4. Meditate",
    "5. Write Journal"
  ];

  // State for daily task completion
  const [dayStatus, setDayStatus] = useState(
    tasks.map(() => Array(7).fill(false)) // 7 days of the week
  );

  // Handle day task completion for the specific day within the week
  const handleDayClick = (taskIndex, dayIndex) => {
    setDayStatus((prevStatus) => {
      const updatedStatus = [...prevStatus];
      updatedStatus[taskIndex][dayIndex] = !updatedStatus[taskIndex][dayIndex];
      return updatedStatus;
    });
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg max-w-3xl mx-auto flex gap-8">
      {/* Left Side: Task List */}
      <div className="flex-1 bg-gray-100 p-4 rounded-md shadow-sm">
        <h2 className="text-xl font-bold mb-4 text-gray-800">Weekly Goals</h2>
        <div className="space-y-2">
          {tasks.map((task, taskIndex) => (
            <div key={taskIndex} className="flex items-center">
              <span className="text-lg text-gray-700">{task}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Right Side: Weekly Calendar */}
      <div className="flex-1 bg-blue-300 p-4 rounded-md shadow-sm">
        <h2 className="text-xl font-bold mb-4 text-gray-800">Calendar (This Week)</h2>

        {/* Display the day labels (columns) */}
        <div className="grid grid-cols-7 gap-5 text-center">
          {days.map((day, dayIndex) => (
            <div key={dayIndex}>
              <h3 className="text-sm font-bold text-gray-700">{day}</h3>
              {/* Display tasks under each day as a column */}
              <div className="flex flex-col items-center space-y-2 mt-2">
                {tasks.map((_, taskIndex) => (
                  <input
                    key={taskIndex}
                    type="checkbox"
                    checked={dayStatus[taskIndex][dayIndex]}
                    onChange={() => handleDayClick(taskIndex, dayIndex)}
                    className={`h-6 w-6 ${dayStatus[taskIndex][dayIndex] ? "bg-green-200" : "bg-gray-200"}`}
                  />
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default WeeklyContainer;


