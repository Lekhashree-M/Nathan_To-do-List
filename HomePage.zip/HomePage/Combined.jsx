import React from 'react';
import NavBar from './NavBar';
import TimeDay from './TimeDay';
import DailyContainer from './DailyContainer';
import WeeklyContainer from './WeeklyContainer';
import GratitudeList from './Gratitudelist';
import Coupons from './Coupons';
import Monthly from './Monthly';
import { Routes, Route, Link } from 'react-router-dom';
import Sidebar from './SideBar';
import { TaskProvider } from '../TaskContext';
import ThemeSwitcher from '../ThemeContext';
import ThemeButton from './ThemeButton';

function Combined() {
  return (
    <TaskProvider>

    <div className="grid grid-rows-[auto_auto_1fr] lg:grid-cols-[300px_1fr] gap-4 min-h-screen p-4">
      {/* NavBar */}
      <div className="bg-blue-100 p-4 rounded shadow-md col-span-full">
        <NavBar />
      </div>

      {/* TimeDay */}
      <div className="bg-green-100 p-4 rounded shadow-md col-span-full">
        <TimeDay />
      </div>

      {/* Sidebar */}
      <div className="bg-gray-100 shadow-md rounded p-4">
        <Sidebar />
      </div>

      {/* Main Goals Content */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Daily Container */}
        <div className="bg-yellow-100 p-4 rounded shadow-md">
          <div className="w-full h-full flex items-center justify-center">
            <Link to="/TodoChecklist">
              <button className="bg-blue-600 text-white px-4 py-2 rounded-md">
                Go to Daily Tasks
              </button>
            </Link>
          </div>
        </div>

        {/* Weekly Container */}
        <div className="bg-red-100 p-4 rounded shadow-md">
          <div className="w-full h-full flex items-center justify-center">
            <WeeklyContainer />
          </div>
        </div>

        {/* Monthly Container (Spans Two Columns) */}
        <div className="bg-purple-100 p-4 rounded shadow-md sm:col-span-2">
          <div className="w-full h-full flex items-center justify-center">
            <Monthly />
          </div>
        </div>
      </div>

      {/* Gratitude and Coupons */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 lg:col-start-2">
        {/* Gratitude List */}
        <div className="bg-teal-100 p-4 rounded shadow-md">
          <div className="w-full h-full flex items-center justify-center">
            <GratitudeList />
          </div>
        </div>

        {/* Coupons */}
        <div className="bg-gray-100 p-4 rounded shadow-md">
          <div className="w-full h-full flex items-center justify-center">
            <Coupons />
          </div>
        </div>
              <div>
                <ThemeButton />
              </div>
        <ThemeSwitcher />
      </div>
    </div>
    </TaskProvider>
  );
}

export default Combined;
