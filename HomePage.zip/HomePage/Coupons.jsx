import React from 'react'
import { useState,useEffect } from "react";

const Coupons = () => {
    const [completedTasks, setCompletedTasks] = useState(["Task 1", "Task 2"]);
    const [coupons, setCoupons] = useState([]);
  
    useEffect(() => {
      const generatedCoupons = completedTasks.map(
        (task) => `Coupon for ${task}`
      );
      setCoupons(generatedCoupons);
    }, [completedTasks]);
  
    return (
      
      <div className="bg-purple-500 p-10 rounded-lg shadow-xl max-w-3xl w-full mx-auto">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">Coupons</h2>
        {coupons.length > 0 ? (
          <ul className="space-y-2">
            {coupons.map((coupon, index) => (
              <li
                key={index}
                className="bg-white p-3 rounded shadow flex justify-between items-center"
              >
                <span>{coupon}</span>
                <button
                  onClick={() =>
                    setCoupons(coupons.filter((_, i) => i !== index))
                  }
                  className="bg-red-500 text-white px-3 rounded"
                >
                  Use
                </button>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-gray-500">No coupons available.</p>
        )}
      </div>
    );
  };
  

  export default Coupons;