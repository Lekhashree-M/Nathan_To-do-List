import React, { useContext, useState } from "react";
import { useNavigate } from "react-router-dom";
import { TaskContext } from "../TaskContext";

const DailyContainer = () => {
  const { tasks } = useContext(TaskContext); // Fetch tasks from context
  const navigate = useNavigate(); // For programmatic navigation
  const days = ["M", "T", "W", "T", "F", "S", "S"]; // Days of the week

  // State to track task completion status for each day
  const [dayStatus, setDayStatus] = useState(
    tasks.map(() => Array(7).fill(false)) // Initialize as false for all days and tasks
  );

  // Toggle the task completion status
  const handleDayClick = (taskIndex, dayIndex) => {
    setDayStatus((prevStatus) => {
      const updatedStatus = [...prevStatus];
      updatedStatus[taskIndex][dayIndex] = !updatedStatus[taskIndex][dayIndex];
      return updatedStatus;
    });
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg max-w-3xl mx-auto flex flex-col gap-8">
      {/* Task List Section */}
      <div className="flex-1 bg-gray-100 p-4 rounded-md shadow-sm">
        <h2 className="text-xl font-bold mb-4 text-gray-800">Daily Goals</h2>
        <div className="space-y-2">
          {tasks.map((task, taskIndex) => (
            <div key={taskIndex} className="flex items-center">
              <span className="text-lg text-gray-700">{task}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Calendar Section */}
      <div className="flex-1 bg-blue-300 p-4 rounded-md shadow-sm">
        <h2 className="text-xl font-bold mb-4 text-gray-800">Calendar (Today)</h2>

        {/* Calendar with checkboxes for each day */}
        <div className="grid grid-cols-7 gap-5 text-center">
          {days.map((day, dayIndex) => (
            <div key={dayIndex}>
              <h3 className="text-sm font-bold text-gray-700">{day}</h3>
              <div className="flex flex-col items-center space-y-2 mt-2">
                {tasks.map((_, taskIndex) => (
                  <input
                    key={taskIndex}
                    type="checkbox"
                    checked={dayStatus[taskIndex][dayIndex]} // Reflect task completion
                    onChange={() => handleDayClick(taskIndex, dayIndex)} // Toggle status
                    className={`h-6 w-6 ${
                      dayStatus[taskIndex][dayIndex] ? "bg-green-400" : "bg-gray-200"
                    } border-gray-500 rounded`}
                  />
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Navigation Button */}
      <div className="text-right mt-4">
        <button
          onClick={() => navigate("/daily-tasks")}
          className="bg-blue-600 text-white px-4 py-2 rounded-md shadow-md hover:bg-blue-700"
        >
          Go to Daily Tasks
        </button>
      </div>
    </div>
  );
};

export default DailyContainer;
