import React from "react";
import { useState,useEffect } from "react";

const GratitudeList = () => {
    const [gratitudes, setGratitudes] = useState([]);
    const [newGratitude, setNewGratitude] = useState("");
  
    const addGratitude = () => {
      if (newGratitude.trim()) {
        setGratitudes([...gratitudes, newGratitude]);
        setNewGratitude("");
      }
    };
  
    const removeGratitude = (index) => {
      setGratitudes(gratitudes.filter((_, i) => i !== index));
    };
  
    return (
      <div className="bg-orange-100 p-6 rounded-lg shadow-lg max-w-3xl  w-full mx-auto">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">Gratitude List</h2>
        <div className="flex gap-2 mb-4">
          <input
            type="text"
            value={newGratitude}
            onChange={(e) => setNewGratitude(e.target.value)}
            placeholder="Enter gratitude"
            className="flex-grow p-2 border rounded focus:outline-none"
          />
          <button
            onClick={addGratitude}
            className="bg-green-500 text-white px-4 rounded"
          >
            Add
          </button>
        </div>
        <ul className="space-y-2">
          {gratitudes.map((gratitude, index) => (
            <li
              key={index}
              className="bg-green-100 p-3 rounded shadow flex justify-between items-center"
            >
              <span>{gratitude}</span>
              <button
                onClick={() => removeGratitude(index)}
                className="bg-red-500 text-white px-2 rounded"
              >
                Remove
              </button>
            </li>
          ))}
        </ul>
      </div>
    );
  };


  export default GratitudeList;
  