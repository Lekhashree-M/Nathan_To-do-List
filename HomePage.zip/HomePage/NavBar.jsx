import React from 'react';
import { Link } from 'react-router-dom';

const NavBar = () => {
  return (
    <nav className="bg-gray-800 text-white p-4 flex justify-between items-center rounded-lg shadow-lg">
      <div className="flex items-center gap-6">
        <Link to="/" className="text-lg font-semibold hover:text-gray-300">
          Home
        </Link>
        <div className="relative group">
          <button className="text-lg font-semibold hover:text-gray-300">
            Goals
          </button>
          <div className="absolute hidden group-hover:block bg-gray-700 rounded shadow-lg mt-2">
            <Link to="/TodoChecklist" className="block px-4 py-2 hover:bg-gray-600">
              Daily Goals
            </Link>
            <Link to="/WeeklyTodoList" className= "block px-4 py-2 hover:bg-gray-600">
              Weekly Goals
            </Link>
            <Link to="/WeeklyTodoList" className="block px-4 py-2 hover:bg-gray-600">
              Monthly Goals
            </Link>
          </div>
        </div>
      </div>
      <div className="flex items-center gap-6">
        <div className="relative group">
          <button className="flex items-center gap-2 text-lg font-semibold hover:text-gray-300">
            <img
              src="https://www.gravatar.com/avatar?d=mp"
              alt="Profile"
              className="w-8 h-8 rounded-full"
            />
            <span>Username</span>
          </button>
        </div>
        <div className="flex items-center gap-4">
          <span className="bg-purple-600 text-white px-3 py-1 rounded-lg">
            Coins: 0
          </span>
          <span className="bg-orange-500 text-white px-3 py-1 rounded-lg">
            Level: 1
          </span>
        </div>
      </div>
    </nav>
  );
};

export default NavBar;
