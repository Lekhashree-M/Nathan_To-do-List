import React, { useState } from "react";
import { Link } from "react-router-dom";


const Sidebar = () => {
  const [isOpen, setIsOpen] = useState(true); // State to manage sidebar visibility

  const toggleSidebar = () => {
    setIsOpen(!isOpen); // Toggle sidebar visibility
  };

  return (
    <div
      className={`transition-all duration-300 ease-in-out h-screen ${
        isOpen ? "w-64" : "w-20"
      } bg-violet-400 text-white p-4`} // Dynamic width with Tailwind classes
    >
      <div className="flex flex-col h-full">
        {/* Sidebar Header: Toggle Button */}
        <div className="flex justify-between items-center mb-4">
          <h2
            className={`text-xl font-bold mb-4 ${
              isOpen ? "" : "hidden"
            }`} // Hide title when collapsed
          >
            Menu
          </h2>
          <button onClick={toggleSidebar} className="text-white">
            {/* Button Icon */}
            <span className={`${isOpen ? "hidden" : ""} text-2xl`}>☰</span> {/* Hamburger Icon */}
            <span className={`${isOpen ? "" : "hidden"} text-xl`}>X</span> {/* Close Icon */}
          </button>
        </div>

        {/* Sidebar Menu */}
        <ul className="space-y-2">
          <li>
            <Link
              to="/todays-tasks"
              className="block px-3 py-2 hover:bg-violet-700 rounded"
            >
              {isOpen && "Today's Tasks"}
            </Link>
          </li>
          <li>
            <Link
              to="/completed-tasks"
              className="block px-3 py-2 hover:bg-violet-700 rounded"
            >
              {isOpen && "Completed Tasks"}
            </Link>
          </li>
          <li>
            <Link
              to="/upcoming-tasks"
              className="block px-3 py-2 hover:bg-violet-700 rounded"
            >
              {isOpen && "Upcoming Tasks"}
            </Link>
          </li>
          <li>
            <Link
              to="/overdue-tasks"
              className="block px-3 py-2 hover:bg-violet-700 rounded"
            >
              {isOpen && "Overdue Tasks"}
            </Link>
          </li>
          <li>
            <Link
              to="/priority-levels"
              className="block px-3 py-2 hover:bg-violet-700 rounded"
            >
              {isOpen && "Priority Levels"}
            </Link>
          </li>
          <li>
            <Link
              to="/reminder"
              className="block px-3 py-2 hover:bg-violet-700 rounded"
            >
              {isOpen && "Reminder"}
            </Link>
          </li>
          <li>
            <Link
              to="/theme"
              className="block px-3 py-2 hover:bg-violet-700 rounded"
            >
              {isOpen && "Theme"}
            </Link>
          </li>
          <li>
            <Link
              to="/calendar"
              className="block px-3 py-2 hover:bg-violet-700 rounded"
            >
              {isOpen && "Calendar"}
            </Link>
          </li>
          <li>
            <Link
              to="/coupons"
              className="block px-3 py-2 hover:bg-violet-700 rounded"
            >
              {isOpen && "Coupons"}
            </Link>
          </li>
          <li>
            <Link
              to="/settings"
              className="block px-3 py-2 hover:bg-gray-700 rounded"
            >
              {isOpen && "Settings"}
            </Link>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default Sidebar;
